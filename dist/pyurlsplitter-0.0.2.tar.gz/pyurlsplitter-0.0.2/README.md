
This is a python tool for url-splitting
